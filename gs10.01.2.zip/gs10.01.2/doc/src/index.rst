.. Copyright (C) 2001-2022 Artifex Software, Inc.
.. All Rights Reserved.

.. include:: Readme.rst